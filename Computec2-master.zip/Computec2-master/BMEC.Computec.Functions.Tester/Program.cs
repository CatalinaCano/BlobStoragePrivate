﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;

namespace BMEC.Computec.Functions.Tester
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var client = new WebClient())
            {
                var dataString = "{\"keyDocument\":\"34967758\",\"month\":\"07\",\"year\":\"2019\"}";
                client.Headers.Add(HttpRequestHeader.ContentType, "application/json");
                var resultString = client.UploadString(new Uri("http://localhost:7071/api/DownloadDocument"), "POST", dataString);
                dynamic resultObject = JsonConvert.DeserializeObject(resultString);
                Console.WriteLine(resultObject.format);
                var base64Bytes = resultObject.document.Value;
                byte[] bytes = Convert.FromBase64String(base64Bytes);
                using (FileStream stream = new FileStream(@"c:\tmp\computest.pdf", FileMode.Create, FileAccess.Write, FileShare.Read))
                {
                    stream.Write(bytes, 0, bytes.Length);
                }
            }
        }
    }
}
