using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

/// <summary>
/// name space para las funciones GetPeriods, DownloadDocument y la clase DBContext. 
/// </summary>
namespace BMEC.Computec.Functions
{
    /// <summary>
    /// Funci�n encargada de obtener los periodos por medio de un get retornando un arreglo JSON con el mes y a�o correspondiente
    /// </summary>
    public static class GetPeriods
    {
        /// <summary>
        /// Funcion serverless para la petici�n de periodos a traves de metodo get. 
        /// </summary>
        /// <param name="req">par�metro para leer el query de la petici�n.</param>
        /// <param name="log">variable utilizada para realizar el registro (log)</param>
        /// <returns>retorna el resultado de una acci�n de metodo</returns>
        [FunctionName("GetPeriods")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = null)] HttpRequest req,
            ILogger log)
        {
            //obtenci�n de los valores para el query de consulta de periodos.
            var keyDocument = req.Query["keyDocument"].FirstOrDefault();

            if (keyDocument != null && keyDocument!="")
            {
                #region GetPeriods
                //Llamado a la clase de comunicaci�n con la base de datos para lo obtenci�n de un objeto JSON con los periodos 
                string dbResponse = await DBContext.GetPeriods(keyDocument);
                //Creaci�n de clase din�mica para la obtenci�n del JSON de respuesta especificado. 
                dynamic dbResponseArray = JArray.Parse(dbResponse);
                #endregion
                //Creaci�n de lista en funci�n de la clase din�mica para la serilizaci�n de la respuesta requerida.
                var results = new List<object>();
                foreach (var record in dbResponseArray)
                {
                    results.Add(new
                    {
                        month = ((DateTime)record.FECHA_CREACION).Month,
                        year = ((DateTime)record.FECHA_CREACION).Year
                    });
                }
                //Serializaci�n y env�o.
                var json = JsonConvert.SerializeObject(results);
                if (json != "[]")
                    return (ActionResult)new OkObjectResult(json);
                else
                    return new NotFoundObjectResult("File not found");
            }
            else
                return new BadRequestObjectResult("Please pass the values on the query string or in the request body");
        }
    }
}
