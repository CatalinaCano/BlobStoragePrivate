﻿using Microsoft.Azure.KeyVault;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;


namespace BMEC.Computec.Functions
{
    /// <summary>
    /// Clase de comunicación con la base de datos que hace transparente el acceso de las functions a la misma,
    /// para el listado de periodos y la descarga de documentos.
    /// </summary>
    static class DBContext
    {
        //Variable para conexión con key vault de azure para leer la cadena de conexión en una forma más segura
        //estos parametros cambian en funcion de la aplicación inscrita en el AD de azure y el secreto correspondiente
        //solo las funciones inscritas tienen acceso a este secreto en el key vault.
        private const string applicationId = "0900b501-e087-4126-8cd9-960fa032774e";
        private const string applicationSecret = "04[?o@?RIXj86R27I8b31HMgzzWjNnw+";

        /// <summary>
        /// Función privada para la ejecución del query a la DB  
        /// </summary>
        /// <example><code source="..\DBContext.cs" region="ExecuteQuery" lang="C#" 
        /// title="" />ExecuteQuery</example>
        /// <param name="query">Parámetro usado para la solicitud de periodos y/o documentos</param>
        /// <returns>Retorna el resultado propio de la consulta especificada como objeto JSON</returns>
        private static async Task<string> ExecuteQuery(string query)
        {
            var keyClient = new KeyVaultClient(async (authority, resource, scope) =>
            {
                var adCredential = new ClientCredential(applicationId, applicationSecret);
                var authenticationContext = new AuthenticationContext(authority, null);
                return (await authenticationContext.AcquireTokenAsync(resource, adCredential)).AccessToken;
            });

            //url del secreto correspondiente al connection string de la DB.
            var secretIdentifier = "https://computeckeyvault.vault.azure.net/secrets/CONNECTIONSTRING/5070dab22dbf4b1b8b63784874862766";
            var secret = await keyClient.GetSecretAsync(secretIdentifier);

            DataTable dataTable = new DataTable();
            using (SqlConnection conn = new SqlConnection(secret.Value))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dataTable);
                conn.Close();
                string JSONString = JsonConvert.SerializeObject(dataTable);
                return JSONString;
            }
        }

        /// <summary>
        /// Función con query para la busqueda del documento actual para cliente, mes y año especificados
        /// </summary>
        /// <example><code source="..\DownloadDocument.cs" region="GetDocuments" lang="C#" 
        /// title="" />ExecuteQuery</example>
        /// <param name="keyDocument">identificación del cliente</param>
        /// <param name="month">mes del documento</param>
        /// <param name="year">año del documento</param>
        /// <returns>retorna un objeto JSON que incluye la url de los documentos para descargar.</returns>
        public static async Task<string> GetDocuments(string keyDocument, string month, string year)
        {
            #region ExecuteQuery
            var query = $"SELECT A.CODIGO_CLIENTE,A.CODIGO_PRODUCTO,A.CAMPO_STR_1,A.FECHA_CREACION,ARCHIVO_1," +
                            $"B.CUENTA_AZURE,B.LLAVE FROM[DBO].[TBL_ALMACENAMIENTO] A " +
                            $"INNER JOIN TBL_CLIENTE_PRODUCTO_ALMACENAMIENTO_AZURE B ON A.CODIGO_CLIENTE=B.CODIGO_CLIENTE" +
                            $" AND A.CODIGO_PRODUCTO=B.CODIGO_PRODUCTO AND A.CODIGO_CLIENTE = 9999 AND campo_str_1 = '{keyDocument}'" +
                            $" WHERE DATEPART(month, FECHA_CREACION) = {Convert.ToUInt32(month)}" +
                            $" and DATEPART(year, FECHA_CREACION) = {Convert.ToUInt32(year)} ORDER BY FECHA_CREACION DESC";
            return await ExecuteQuery(query);
            #endregion
        }

        /// <summary>
        /// Función con query para la busqueda de los periodos correspondientes al keyDocument (identificación del cliente)
        /// </summary>
        /// <example><code source="..\GetPeriods.cs" region="GetPeriods" lang="C#" 
        /// title="" />ExecuteQuery</example>
        /// <param name="keyDocument">identificación del cliente</param>
        /// <returns>retorna un objeto JSON que incluye las fechas de los periodos consultados por el query.</returns>
        public static async Task<string> GetPeriods(string keyDocument)
        {
            var query = $"SELECT A.CODIGO_CLIENTE,A.CODIGO_PRODUCTO,A.CAMPO_STR_1,A.FECHA_CREACION,ARCHIVO_1," +
                $"B.CUENTA_AZURE,B.LLAVE FROM[DBO].[TBL_ALMACENAMIENTO] A " +
                $"INNER JOIN TBL_CLIENTE_PRODUCTO_ALMACENAMIENTO_AZURE B ON A.CODIGO_CLIENTE=B.CODIGO_CLIENTE" +
                $" AND A.CODIGO_PRODUCTO=B.CODIGO_PRODUCTO AND A.CODIGO_CLIENTE=9999" +
                $" and campo_str_1 = '{keyDocument}' ORDER BY FECHA_CREACION DESC";
            return await ExecuteQuery(query);
        }
    }
}