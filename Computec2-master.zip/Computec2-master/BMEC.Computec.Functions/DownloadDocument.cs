using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;


namespace BMEC.Computec.Functions
{
    /// <summary>
    /// Funci�n encargada de descargar el documento actual en base64 del mes y a�o espec�ficos, retornando 
    /// un objeto JSON con un base64 de los Bytes del documento descargado y el tipo de archivo (extensi�n del archivo ej: pdf).
    /// </summary>
    public static class DownloadDocument
    {
        /// <summary>
        /// Funci�n serverless para la petici�n de documento a traves de metodo post. 
        /// </summary>
        /// <param name="req">par�metro para leer el body de la petici�n</param>
        /// <param name="log">variable utilizada para realizar el registro (log)</param>
        /// <returns>retorna el resultado de una acci�n de metodo</returns>
        [FunctionName("DownloadDocument")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");
            //recibe y procesa los parametros del objeto JSON en el body.
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            #region GetDocuments
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            //separa los datos para crear el query y poder descargar el documento seg�n el criterio keyDocument, month, year.
            string keyDocument = data.keyDocument;
            string month = data.month;
            string year = data.year;
            //ejecuta query para la obtenci�n de la url de los archivos seg�n el criterio keyDocument, month, year
            //retornando un objeto JSON con esta informaci�n.
            string documentsJSON = await DBContext.GetDocuments(keyDocument, month, year);
            // crea una clase din�mica para poder acceder a los datos del objeto JSON en respuesta al query
            dynamic dbResponseArray = JArray.Parse(documentsJSON);
            #endregion
            //Espera que la consulta a la DB se ejecute clasificando los registros por fecha de forma descendente.
            string pdfUrl = dbResponseArray[0].ARCHIVO_1;
            string cuenta = dbResponseArray[0].CUENTA_AZURE;
            string key = dbResponseArray[0].LLAVE;
            /*//valores de prueba para verificar la descarga con storage privado
            pdfUrl = "https://pruebacomputec2096139985.blob.core.windows.net/testdownloadpdf/CupoRotativo_4080022927.pdf";
            cuenta = "pruebacomputec2096139985";
            key = "m44hC4uy7OwIeTEXcp / IV9h8eC2 / u + oeNllEdN2Gkw2JQ4LyjN2L2glKk9ZRDS7q03Jid9408gnvIK0V80qZ0w ==";
            */
            string storageConnectionString = "DefaultEndpointsProtocol=https;"+
                                            $"AccountName={cuenta}"+
                                            $";AccountKey={key}"+
                                            ";EndpointSuffix=core.windows.net";
            CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(storageConnectionString);
            CloudBlobClient blobClient = cloudStorageAccount.CreateCloudBlobClient();
            String containerName = pdfUrl.Substring(pdfUrl.IndexOf(".net/") + 5);
            containerName = containerName.Substring(0, containerName.IndexOf("/"));
            String fileName = pdfUrl.Substring(pdfUrl.IndexOf(containerName) + containerName.Length+1);
            CloudBlobContainer cloudBlobContainer = blobClient.GetContainerReference(containerName);
            CloudBlockBlob blockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
            MemoryStream memStream = new MemoryStream();
            //Descarga el documento y lo convierte en base64
            await blockBlob.DownloadToStreamAsync(memStream);
            var bytes = memStream.ToArray();
            string base64Bytes = Convert.ToBase64String(bytes);
            String format = Path.GetExtension(pdfUrl);
            format = format.Substring(1, format.Length - 1);
            //Crea el objeto para serializarlo.
            var document = new
            {
                document = base64Bytes,
                format = format
            };
            //Serializa el objeto y lo env�a.
            var json = JsonConvert.SerializeObject(document);
            return data != null
                ? (ActionResult)new OkObjectResult(json)
                : new BadRequestObjectResult("Please pass the values on the query string or in the request body");
        }
    }
}
